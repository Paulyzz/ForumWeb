const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const QuestionSchema = new Schema(
  {
    space: {
      type: String,
    },
    title: {
      type: String,
    },
    content: {
      type: String,
    },
    answer: {
      type: String,
    },
    up: {
      type: String,
    },
    creatorid: {
      type: String,
    },
    creatorName: {
      type: String,
    },
    createTime: {
      type: Date,
      default: Date.now,
    },
    updateTime: {
      type: Date,
      default: Date.now,
    },
  },
  {
    timestamps: { createdAt: "createTime", updatedAt: "updateTime" },
  }
);
module.exports = Question = mongoose.model("question", QuestionSchema);
