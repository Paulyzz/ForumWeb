const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const AnswerSchema = new Schema(
  {
    qid: {
      type: Schema.Types.ObjectId,
    },
    content: {
      type: String,
    },
    uid: {
      type: String,
    },
    uname: {
      type: String,
    },
    createTime: {
      type: Date,
      default: Date.now,
    },
    updateTime: {
      type: Date,
      default: Date.now,
    },
  },
  {
    timestamps: { createdAt: "createTime", updatedAt: "updateTime" },
  }
);
module.exports = Answer = mongoose.model("Answer", AnswerSchema);
