const express = require("express");
const router = express.Router();
const User = require("../model/User");
//register
router.post("/register", (req, res) => {
  let { name, email, password } = req.body;
  User.findOne({ email }).then((userinfo) => {
    if (userinfo) {
      return res.status(200).json({ msg: "Duplicated email address", data: [] });
    }
    new User({ name, email, password }).save().then((data) => {
      res.json({ msg: "ok", data: data });
    });
  });
});
//login
router.post("/login", (req, res) => {
  let { email, password } = req.body;
  User.findOne({ email }).then((userinfo) => {
    if (!userinfo) {
      return res.status(200).json({ msg: "User is not  registered", data: [] });
    } else {
      if (userinfo.password !== password) {
        return res.status(200).json({ msg: "Unauthorized access", data: [] });
      } else {
        res.json({ msg: "ok", data: userinfo });
      }
    }
  });
});
module.exports = router;
