const { json } = require("body-parser");
const express = require("express");
const router = express.Router();
const Answer = require("../model/Answer");

router.post("/add", (req, res) => {
  let { qid, content, uid, uname } = req.body;
  new Answer({ qid, content, uid, uname }).save().then((data) => {
    res.json({ msg: "ok", data: data });
  });
});

router.get("/all", (req, res) => {
  let { qid } = req.query;
  Answer.find({ qid: qid })
    .sort({ createTime: -1 })
    .then((data) => {
      res.json({ msg: "ok", data: data });
    });
});

router.get("/delete", (req, res) => {
  let { _id } = req.query;
  Answer.deleteOne({ _id: _id }, (data) => {
    console.log(data);
    res.json({ msg: "ok", data: data });
  });
});

module.exports = router;
