const { json } = require("body-parser");
const express = require("express");
const router = express.Router();
const Question = require("../model/Question");
const Answer = require("../model/Answer");

router.post("/add", (req, res) => {
  let { title, space, content, creatorid, creatorName } = req.body;
  new Question({ title, space, content, creatorid, creatorName, up: JSON.stringify([]) }).save().then((data) => {
    if (data) {
      res.json({ msg: "ok", data: data });
    } else {
      return res.status(200).json({ msg: "service error", data: [] });
    }
  });
});

router.post("/update", (req, res) => {
  let { title, space, content, _id } = req.body;

  // res.json({ msg: "ok", data: 1111 });
  Question.findByIdAndUpdate(_id, {
    title,
    space,
    content,
  }).then((data) => {
    res.json({ msg: "ok", data: data });
  });
});

router.get("/all", (req, res) => {
  Question.aggregate([
    {
      $lookup: {
        from: "answers",
        localField: "_id", // field in the orders collection
        foreignField: "qid", // field in the items collection
        as: "answer",
      },
    },
    {
      $sort: { createTime: -1 },
    },
  ]).then((data) => {
    res.json({ msg: "ok", data: data });
  });
});


router.get("/one", (req, res) => {
  let { _id } = req.query;

  Question.findOne({ _id: _id }).then((data) => {
    res.json({ msg: "ok", data: data });
  });
});

router.post("/up", async (req, res) => {
  let { _id, userid } = req.body;
  let res1 = await Question.findOne({ _id: _id });

  if (!res1.up) {
    let ddd = [];
    ddd.push(userid);
    Question.findByIdAndUpdate(_id, {
      up: JSON.stringify(ddd),
    }).then((data) => {
      res.json({ msg: "ok", data: data });
    });
  } else {
    let res2 = JSON.parse(res1.up);
    let a = [...res2, userid];
    Question.findByIdAndUpdate(_id, {
      up: JSON.stringify(a),
    }).then((data) => {
      res.json({ msg: "ok", data: data });
    });
  }
});

router.post("/cancel", async (req, res) => {
  let { _id, cancelList } = req.body;

  Question.findByIdAndUpdate(_id, {
    up: cancelList,
  }).then((data) => {
    res.json({ msg: "ok", data: data });
  });
});
router.get("/deleteAll", (req, res) => {
  let { id } = req.query;
  Question.deleteOne({ _id: id }, (data) => {
    Answer.remove({ qid: id }, (data) => {
      res.json({ msg: "ok", data: data });
    });
  });
});
module.exports = router;
