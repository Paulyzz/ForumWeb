import request from "../http";

export function add(data) {
  return request({
    url: "/api/question/add",
    method: "post",
    data,
  });
}
export function getAll(data) {
  return request({
    url: "/api/question/all",
    method: "get",
  });
}
export function getOne(data) {
  return request({
    url: "/api/question/one",
    method: "get",
    params: data,
  });
}
export function userUp(data) {
  return request({
    url: "/api/question/up",
    method: "post",
    data,
  });
}
export function userCancel(data) {
  return request({
    url: "/api/question/cancel",
    method: "post",
    data,
  });
}
export function updateQues(data) {
  return request({
    url: "/api/question/update",
    method: "post",
    data,
  });
}

export function deleAllData(data) {
  return request({
    url: "/api/question/deleteAll",
    method: "get",
    params: data,
  });
}
