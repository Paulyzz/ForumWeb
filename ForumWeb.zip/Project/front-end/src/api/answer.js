import request from "../http";

export function add(data) {
  return request({
    url: "/api/answer/add",
    method: "post",
    data,
  });
}
export function allAnswer(data) {
  return request({
    url: "/api/answer/all",
    method: "get",
    params: data,
  });
}
export function deleUserAnswer(data) {
  return request({
    url: "/api/answer/delete",
    method: "get",
    params: data,
  });
}
