import request from "../http";

export function registerUser(data) {
  return request({
    url: "/api/users/register",
    method: "post",
    data,
  });
}
export function login(data) {
  return request({
    url: "/api/users/login",
    method: "post",
    data,
  });
}
