<template>
  <div class="login">
    <section class="form_container">
      <div class="manage_tip">
        <span class="title">Create an account</span>
      </div>
      <el-form :model="registerUser" :rules="rules" inline-message ref="registerForm" class="loginForm" label-width="60px" :validate-on-rule-change="false">
        <el-form-item label="Name" prop="name">
          <el-input v-model="registerUser.name" style="margin-left:50px;width:300px"></el-input>
        </el-form-item>
        <el-form-item label="Email" prop="email">
          <el-input v-model="registerUser.email" style="margin-left:50px;width:300px"></el-input>
        </el-form-item>
        <el-form-item label="Password" prop="password">
          <el-input v-model="registerUser.password" type="password" style="margin-left:50px;width:300px"></el-input>
        </el-form-item>
        <el-form-item label="Confirmation" prop="repassword">
          <el-input v-model="registerUser.repassword" type="password" style="margin-left:50px;width:300px"></el-input>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" class="submit_btn" plain @click="submit">Register</el-button>
        </el-form-item>
      </el-form>
    </section>
  </div>
</template>

<script>
import { registerUser } from "@/api/user";
import { setUserInfo } from "@/cookie";
export default {
  name: "register",
  data() {
    var validatePass2 = (rule, value, callback) => {
      if (value !== this.registerUser.password) {
        callback(new Error("confirmation password is not the same as the password"));
      } else {
        callback();
      }
    };
    return {
      logoutData: "",
      registerUser: {
        name: "",
        email: "",
        password: "",
        repassword: "",
      },
      rules: {
        name: [
          {
            required: true,
            message: "must be filled",
            trigger: "blur",
          },
          {
            min: 2,
            max: 10,
            message: "length from 6 to 10",
            trigger: "blur",
          },
        ],
        email: [
          {
            type: "email",
            required: true,
            message: "email type wrong",
            trigger: "change",
          },
        ],
        password: [
          { required: true, message: "must be filled", trigger: "blur" },
          { min: 6, max: 10, message: "length from 6 to 10", trigger: "blur" },
        ],
        repassword: [
          {
            required: true,
            message: "must be filled",
            trigger: "blur",
          },
          {
            min: 6,
            max: 10,
            message: "length from 6 to 10",
            trigger: "blur",
          },
          {
            validator: validatePass2,
            trigger: "blur",
          },
        ],
      },
    };
  },
  methods: {
    submit() {
      this.$refs["registerForm"].validate((valid) => {
        if (valid) {
          registerUser(this.registerUser).then((res) => {
            if (res.data.msg === "ok") {
              this.$message({
                message: "Register success",
                type: "success",
              });
              setUserInfo(res.data.data);
              this.$router.push("/");
            } else {
              this.$message({
                message: res.data.msg,
                type: "error",
              });
            }
          });
        } else {
          return false;
        }
      });
    },
    isEmpty(value) {
      return value === undefined || value === null || (typeof value === "object" && Object.keys(value).length === 0) || (typeof value === "string" && value.trim().length === 0);
    },
  },
  mounted() {},
};
</script>

<style scoped>
.el-form-item__error {
  color: #f56c6c;
  font-size: 12px;
  line-height: 1;
  padding-top: 4px;
  /* position: absolute; */
  top: 100%;
  left: 50px;
}
.login {
  /* position: relative; */
  width: 100%;
  height: 100%;
  background-size: 100% 100%;
  background-color: #f6f7f9;
}
.form_container {
  width: 500px;
  height: 210px;
  position: absolute;
  top: 20%;
  left: 35%;
  padding: 25px;
  border-radius: 5px;
  text-align: center;
}
.form_container .manage_tip .title {
  font-family: "Microsoft YaHei";
  font-weight: bold;
  font-size: 26px;
  color: black;
}
.loginForm {
  margin-top: 20px;
  background-color: #e7eef6;
  padding: 20px;
  border-radius: 5px;
  box-shadow: 0px 5px 10px #cccc;
}

.submit_btn {
  width: 30%;
  margin-right: 80px;
}
.tiparea {
  text-align: right;
  font-size: 12px;
  color: #333;
}
.tiparea p a {
  color: #409eff;
}
</style>
