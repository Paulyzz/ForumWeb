<template>
  <el-container>
    <el-header> <el-button type="primary" plain @click="$router.push('/')">back</el-button></el-header>
    <el-main style="height:100%;">
      <el-card class="box-card" style="margin-top:30px" v-show="editFlag">
        <div slot="header" class="myheader">
          <span style="border:3px solid #3876C8">{{ radioIndex | filterSpace }}</span>
          <div v-show="btnFlag">
            <el-button type="primary" plain size="mini" @click="Edit">Edit</el-button>
            <el-button type="primary" plain size="mini" @click="deleAll">Delete</el-button>
          </div>
        </div>
        <div style="display:flex">
          <span style="color:#3876C8;font-size:20px">{{ user }}</span>
          <span style="color:#BCBCBC;font-size:20px;margin-left:30px">posted on {{ postTime }}</span>
        </div>
        <div>
          <h1 style="font-size:35px">{{ title }}</h1>
        </div>
        <div>
          <h3>{{ content }}</h3>
        </div>
      </el-card>
      <el-card class="box-card" style="margin-top:30px" v-show="!editFlag">
        <el-form :model="askQuestion" :rules="rules" ref="askQuestionForm" class="loginForm" label-width="60px" inline-message>
          <el-form-item label="Title" prop="title">
            <el-input v-model="askQuestion.title" style="width:300px"></el-input>
          </el-form-item>
          <el-form-item label="Space" prop="space">
            <el-radio-group v-model="askQuestion.space">
              <el-radio label="0">Algorithm</el-radio>
              <el-radio label="1">Machine Learning</el-radio>
              <el-radio label="2">System</el-radio>
              <el-radio label="3">JavaScript</el-radio>
            </el-radio-group>
          </el-form-item>
          <el-form-item label="Content" prop="content">
            <el-input v-model="askQuestion.content" type="textarea" style="width:300px"></el-input>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" class="submit_btn" plain @click="editSubmit">submit</el-button>
          </el-form-item>
        </el-form>
      </el-card>
      <el-card class="box-card" style="margin-top:30px;margin-left:44px" v-for="(item, index) in answerList" :key="index">
        <div style="display:flex;justify-content: space-between;">
          <div>
            <span style="color:#3876C8;font-size:20px">{{ item.uname }}</span>
            <span style="color:#BCBCBC;font-size:20px;margin-left:30px">answered on {{ item.createTime }}</span>
          </div>
          <div>
            <el-button type="primary" plain size="mini" v-show="item.uname == userName" @click="deleUAnswer(item._id)">Delete</el-button>
          </div>
        </div>
        <div>
          <h3>{{ item.content }}</h3>
        </div>
      </el-card>
      <el-card class="box-card" style="margin-top:30px;margin-left:44px" v-if="userName">
        <div style="display:flex">
          <span style="color:#3876C8;font-size:20px">{{ userName }}</span>
        </div>
        <div style="margin-top:30px">
          <el-input type="textarea" v-model="textarea" placeholder="Post your new answer"> </el-input>
          <div style="margin-top:30px">
            <el-button type="primary" plain size="mini" @click="submit">submit</el-button>
            <el-button type="primary" plain size="mini">cancel</el-button>
          </div>
        </div>
      </el-card>
    </el-main>
  </el-container>
</template>

<script>
import { getUserInfo } from "@/cookie";
import { getOne, updateQues, deleAllData } from "@/api/question";
import { add, allAnswer, deleUserAnswer } from "@/api/answer";
function rTime(date) {
  var json_date = new Date(date).toJSON();
  return new Date(new Date(json_date) + 8 * 3600 * 1000)
    .toISOString()
    .replace(/T/g, " ")
    .replace(/\.[\d]{3}Z/, "")
    .substring(0, 10);
}
export default {
  name: "",
  filters: {
    filterSpace(data) {
      switch (data) {
        case "0":
          return "Algorithm";
          break;
        case "1":
          return "Machine Learning";
          break;
        case "2":
          return "System";
          break;
        default:
          return "JavaScript";
          break;
      }
    },
  },
  data() {
    return {
      pid: "",
      user: "",
      postTime: "",
      title: "",
      content: "",
      radioIndex: "",
      textarea: "",
      answerList: [],
      userName: "",
      btnFlag: false,
      editFlag: true,
      askQuestion: {
        title: "",
        space: "",
        content: "",
      },
      rules: {
        title: [{ required: true, message: "must be filled", trigger: "blur" }],
        space: [{ required: true, message: "must be filled", trigger: "change" }],
        content: [{ required: true, message: "must be filled", trigger: "blur" }],
      },
    };
  },
  created() {
    this.pid = this.$route.params.quesid;

    this.getMain();
    this.getAllAnswer();
  },
  methods: {
    getMain() {
      let res1 = getUserInfo();
      if (res1) {
        let res = JSON.parse(res1);
        this.userName = res.name;
      }
      getOne({ _id: this.pid }).then((res) => {
        this.user = res.data.data.creatorName;
        this.postTime = rTime(res.data.data.createTime);
        this.title = res.data.data.title;
        this.content = res.data.data.content;
        this.radioIndex = res.data.data.space;
        if (this.userName == this.user) {
          this.btnFlag = true;
        }
      });
    },
    submit() {
      let res1 = getUserInfo();

      let res = JSON.parse(res1);
      let submitData = {
        qid: this.pid,
        content: this.textarea,
        uid: res._id,
        uname: res.name,
      };
      add(submitData).then((res) => {
        this.getAllAnswer();
      });
    },
    getAllAnswer() {
      allAnswer({ qid: this.pid }).then((res) => {
        this.answerList = res.data.data.map((v) => {
          let obj = { ...v };
          obj.createTime = rTime(obj.createTime);
          return obj;
        });
      });
    },
    Edit() {
      this.editFlag = false;
      this.askQuestion.title = this.title;
      this.askQuestion.space = this.radioIndex;
      this.askQuestion.content = this.content;
    },
    editSubmit() {
      this.$refs["askQuestionForm"].validate((valid) => {
        if (valid) {
          let updateData = {
            _id: this.pid,
            ...this.askQuestion,
          };
          updateQues(updateData).then((res) => {
            this.getMain();
          });
          this.editFlag = true;
        } else {
          console.log("error submit!!");
          return false;
        }
      });
    },
    deleUAnswer(data) {
      deleUserAnswer({ _id: data }).then((res) => {
        this.getAllAnswer();
      });
    },
    deleAll() {
      deleAllData({ id: this.pid }).then((res) => {
        console.log(res);
        this.$router.push("/");
      });
    },
  },
};
</script>

<style scoped>
.myheader {
  display: flex;
  justify-content: space-between;
}
</style>
