<template>
  <el-container>
    <el-header> <el-button type="primary" plain @click="$router.push('/')">back</el-button></el-header>
    <el-main>
      <section class="form_container">
        <div class="manage_tip">
          <span class="title">Ask your question</span>
        </div>
        <el-form :model="askQuestion" :rules="rules" ref="askQuestionForm" class="loginForm" label-width="60px" inline-message>
          <el-form-item label="Title" prop="title">
            <el-input v-model="askQuestion.title" style="width:300px"></el-input>
          </el-form-item>
          <el-form-item label="Space" prop="space">
            <el-radio-group v-model="askQuestion.space">
              <el-radio label="0">Algorithm</el-radio>
              <el-radio label="1">Machine Learning</el-radio>
              <el-radio label="2">System</el-radio>
              <el-radio label="3">JavaScript</el-radio>
            </el-radio-group>
            <!-- <el-input v-model="askQuestion.space" type="password" style="margin-left:50px;width:300px"></el-input> -->
          </el-form-item>
          <el-form-item label="Content" prop="content">
            <el-input v-model="askQuestion.content" type="textarea" style="width:300px"></el-input>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" class="submit_btn" plain @click="submit">submit</el-button>
          </el-form-item>
        </el-form>
      </section>
    </el-main>
  </el-container>
</template>

<script>
import { add } from "@/api/question";
import { getUserInfo } from "@/cookie";
export default {
  name: "",
  data() {
    return {
      askQuestion: {
        title: "",
        space: "",
        content: "",
      },
      rules: {
        title: [{ required: true, message: "must be filled", trigger: "blur" }],
        space: [{ required: true, message: "must be filled", trigger: "change" }],
        content: [{ required: true, message: "must be filled", trigger: "blur" }],
      },
    };
  },
  methods: {
    submit() {
      this.$refs["askQuestionForm"].validate((valid) => {
        if (valid) {
          // alert("submit!");
          let userInfo = JSON.parse(getUserInfo());
          this.askQuestion.creatorid = userInfo._id;
          this.askQuestion.creatorName = userInfo.name;
          add(this.askQuestion).then((res) => {
            if (res.data.msg === "ok") {
              this.$message({
                message: "submit success",
                type: "success",
              });
              this.$router.push("/");
            } else {
              this.$message({
                message: res.data.msg,
                type: "error",
              });
            }
            console.log(res);
          });
        } else {
          console.log("error submit!!");
          return false;
        }
      });
      console.log(this.askQuestion);
    },
  },
};
</script>

<style scoped>
.login {
  /* position: relative; */
  width: 100%;
  height: 100%;
  background-size: 100% 100%;
  background-color: #f6f7f9;
}
.form_container {
  width: 700px;
  height: 210px;
  position: absolute;
  top: 20%;
  left: 35%;
  padding: 25px;
  border-radius: 5px;
  text-align: center;
}
.form_container .manage_tip .title {
  font-family: "Microsoft YaHei";
  font-weight: bold;
  font-size: 26px;
  color: black;
}
.loginForm {
  margin-top: 20px;
  background-color: #e7eef6;
  padding: 20px;
  border-radius: 5px;
  box-shadow: 0px 5px 10px #cccc;
}

.submit_btn {
  width: 30%;
  margin-right: 80px;
}
.tiparea {
  text-align: right;
  font-size: 12px;
  color: #333;
}
.tiparea p a {
  color: #409eff;
}
</style>
