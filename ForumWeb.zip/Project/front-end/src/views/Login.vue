<template>
  <div class="login">
    <section class="form_container">
      <div class="manage_tip">
        <span class="title">SIGN IN</span>
      </div>
      <el-form :model="loginUser" :rules="rules" ref="loginForm" class="loginForm" label-width="60px" inline-message>
        <el-form-item label="Email" prop="email">
          <el-input v-model="loginUser.email" style="margin-left:50px;width:300px"></el-input>
        </el-form-item>
        <el-form-item label="Password" prop="password">
          <el-input v-model="loginUser.password" type="password" style="margin-left:50px;width:300px"></el-input>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="submitForm('loginForm')" class="submit_btn" plain>Log in</el-button>
        </el-form-item>
      </el-form>
      <div style="margin-top:30px">
        <span>Do not have an account？</span>
      </div>
      <div style="margin-top:30px;">
        <el-button type="primary" style="margin-right:40px" plain @click="toResgister">Register</el-button>
      </div>
    </section>
  </div>
</template>

<script>
import { login } from "@/api/user";
import { setUserInfo } from "@/cookie";
export default {
  name: "login",
  data() {
    return {
      logoutData: "",
      loginUser: {
        email: "",
        password: "",
      },
      rules: {
        email: [
          {
            type: "email",
            required: true,
            message: "email type wrong",
            trigger: "change",
          },
        ],
        password: [
          { required: true, message: "must be filled", trigger: "blur" },
          { min: 6, max: 10, message: "length from 6 to 10", trigger: "blur" },
        ],
      },
    };
  },
  methods: {
    toResgister() {
      this.$router.push("/register");
    },
    submitForm(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          login(this.loginUser).then((res) => {
            if (res.data.msg === "ok") {
              setUserInfo(res.data.data);
              this.$router.push("/");
            } else {
              this.$message({
                message: res.data.msg,
                type: "error",
              });
            }
          });
        } else {
          return false;
        }
      });
    },
  },
  mounted() {
    //
    //
    //
    if (this.$route.query.id != undefined) {
      this.$socket.emit("logout");
    }
  },
  sockets: {
    users(data) {
      //

      this.$store.state.onLineuser = data;
    },
  },
};
</script>

<style scoped>
.login {
  /* position: relative; */
  width: 100%;
  height: 100%;
  background-size: 100% 100%;
  background-color: #f6f7f9;
}
.form_container {
  width: 500px;
  height: 210px;
  position: absolute;
  top: 20%;
  left: 35%;
  padding: 25px;
  border-radius: 5px;
  text-align: center;
}
.form_container .manage_tip .title {
  font-family: "Microsoft YaHei";
  font-weight: bold;
  font-size: 26px;
  color: black;
}
.loginForm {
  margin-top: 20px;
  background-color: #e7eef6;
  padding: 20px;
  border-radius: 5px;
  box-shadow: 0px 5px 10px #cccc;
}

.submit_btn {
  width: 30%;
  margin-right: 80px;
}
.tiparea {
  text-align: right;
  font-size: 12px;
  color: #333;
}
.tiparea p a {
  color: #409eff;
}
</style>
