import Cookies from "js-cookie";

const InfoKey = "info";

export function getUserInfo() {
  return Cookies.get(InfoKey);
}

export function setUserInfo(info) {
  return Cookies.set(InfoKey, info);
}
export function removeUserInfo() {
  return Cookies.remove(InfoKey);
}
