<template>
  <div>
    <header class="head-nav">
      <el-row>
        <el-col :span="3" class="logo-container hand" @click="clickLogo"> <span @click="clickLogo">Ques</span> </el-col>
        <el-col :span="3" class="btn-flex">
          <el-button type="text" @click="clickHome">Home</el-button>
          <el-button type="text" @click="clickHot">Hot</el-button>
        </el-col>
        <el-col :span="14">
          <div class="logo-container">
            <el-input v-model="input" style="width:400px;margin-left:100px"></el-input>
          </div>
        </el-col>
        <el-col :span="4" class="btn-flex">
          <el-button type="text" @click="$router.push('/login')" v-show="flag">Log in</el-button>
          <el-button type="text" @click="$router.push('/register')" v-show="flag">Resigter</el-button>
          <el-button type="text" @click="clearCookie" v-show="!flag">Log Out</el-button>
        </el-col>
      </el-row>
    </header>
  </div>
</template>

<script>
import { getUserInfo, removeUserInfo } from "@/cookie";
export default {
  name: "MyHeader",
  data() {
    return {
      input: "",
      flag: false,
    };
  },
  watch: {
    input(val) {
      this.$emit("update:inputvalue", val);
    },
  },
  methods: {
    clearCookie() {
      removeUserInfo();
      this.flag = true;
      this.$emit("update:logFlag", this.flag);
    },
    clickHot() {
      this.$emit("hotFlag");
    },
    clickHome() {
      this.$emit("homeFlag");
    },
    clickLogo() {
      this.$emit("Logobtn");
    },
  },

  created() {
    let res = getUserInfo();
    if (res) {
      this.flag = false;
      this.$emit("update:logFlag", this.flag);
    } else {
      this.flag = true;
      this.$emit("update:logFlag", this.flag);
    }
  },
};
</script>
<style scoped>
.el-button {
  font-size: 25px;
  color: #323232;
}
.el-col-4 {
  width: 13%;
}
.head-nav {
  width: 100%;
  height: 60px;
  min-width: 600px;
  background: #f5f7f8;
  color: #323232;
}
.logo-container {
  line-height: 60px;
  font-size: 30px;
  /* text-align: center; */
}
.btn-flex {
  display: flex;

  align-items: center;
  justify-content: space-between;
}
.header-input {
  line-height: 60px;
  /* margin-left: 50px; */
}
.hand {
  cursor: pointer;
}
</style>
