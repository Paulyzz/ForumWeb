<template>
  <el-container>
    <el-header><my-header :logFlag.sync="logFlag" @hotFlag="clickHot" @homeFlag="clickHome" @Logobtn="logoBtn" :inputvalue.sync="ivalue"></my-header></el-header>
    <el-container>
      <el-aside width="500px" style="height:100%;padding:70px">
        <div>
          <el-menu @select="handleSelect">
            <el-menu-item index="0">
              <span slot="title">Algorithm</span>
            </el-menu-item>
            <el-menu-item index="1">
              <span slot="title">Machine Learning</span>
            </el-menu-item>
            <el-menu-item index="2">
              <span slot="title">System</span>
            </el-menu-item>
            <el-menu-item index="3">
              <span slot="title">JavaScript</span>
            </el-menu-item>
          </el-menu>
        </div>
      </el-aside>
      <el-main style="height:100%;padding:70px">
        <div style=" flex: 1; text-align: right;" v-show="!logFlag">
          <el-button type="primary" plain @click="$router.push('/ask')">Ask Question</el-button>
        </div>
        <el-card class="box-card" style="margin-top:30px" v-show="!logFlag">
          <div slot="header" class="clearfix">
            <span style="color:#3876C8;font-size:30px">{{ username }}</span>
          </div>
          <h1 @click="$router.push('/ask')">What is your question?</h1>
        </el-card>
        <div v-for="(item, index) in questionsList" :key="index">
          <el-card class="box-card" style="margin-top:30px">
            <div slot="header" class="clearfix">
              <span style="border:3px solid #3876C8">{{ item.space | filterSpace }}</span>
            </div>
            <el-row>
              <el-col :span="4">
                <div style="background-color:#D8E3F5;width:70%;height:50px;font-size:30px">
                  {{ item.creatorName }}
                </div>
                <div style="margin-top:15px;color:#BCBCBC">
                  {{ item.createTime }}
                </div>
              </el-col>
              <el-col :span="20">
                <div style="font-size:22px">
                  <h1 class="hand" @click="$router.push(`/detail/${item._id}`)">{{ item.title }}</h1>
                  <span>{{ item.content }}</span>
                </div>
              </el-col>
            </el-row>
            <div class="footer">
              <div class="hand" @click="Upvote(item._id)" v-show="!item.upFlag">
                <i class=" el-icon-caret-top" style="font-size:22px"></i>
                <span>Upvote( {{ item.upNum }} )</span>
              </div>
              <div class="hand" @click="cancelUp(item._id, item.up)" v-show="item.upFlag">
                <span>voted( {{ item.upNum }} )</span>
              </div>
              <div class="hand" @click="answerList(item.answer, index)">
                <i class=" el-icon-edit" style="font-size:22px;margin-left:30px"></i>
                <span>Answer( {{ item.answer.length }} )</span>
              </div>
            </div>
          </el-card>
          <el-card class="box-card" style="margin-top:30px;margin-left:44px" v-show="item.answerFlag" v-for="(i, k) in item.answer" :key="k">
            <div style="display:flex;justify-content: space-between;">
              <div>
                <span style="color:#3876C8;font-size:20px">{{ i.uname }}</span>
                <span style="color:#BCBCBC;font-size:20px;margin-left:30px">answered on {{ 1111 }}</span>
              </div>
            </div>
            <div>
              <h3>{{ i.content }}</h3>
            </div>
          </el-card>
          <el-card class="box-card" style="margin-top:30px;margin-left:44px" v-if="!logFlag && item.answerFlag">
            <div style="display:flex">
              <span style="color:#3876C8;font-size:20px">{{ username }}</span>
            </div>
            <div style="margin-top:30px">
              <el-input type="textarea" v-model="textarea" placeholder="Post your new answer"> </el-input>
              <div style="margin-top:30px">
                <el-button type="primary" plain size="mini" @click="answerSubmit(item._id)">submit</el-button>
              </div>
            </div>
          </el-card>
        </div>
      </el-main>
    </el-container>
  </el-container>
</template>

<script>
import MyHeader from "../MyHeader";
import { getUserInfo } from "@/cookie";
import { getAll, userUp, userCancel } from "@/api/question";
import { add } from "@/api/answer";
function rTime(date) {
  var json_date = new Date(date).toJSON();
  return new Date(new Date(json_date) + 8 * 3600 * 1000)
    .toISOString()
    .replace(/T/g, " ")
    .replace(/\.[\d]{3}Z/, "")
    .substring(0, 10);
}
export default {
  name: "Layout",
  components: {
    MyHeader,
  },
  filters: {
    filterSpace(data) {
      switch (data) {
        case "0":
          return "Algorithm";
          break;
        case "1":
          return "Machine Learning";
          break;
        case "2":
          return "System";
          break;
        default:
          return "JavaScript";
          break;
      }
    },
  },
  data() {
    return {
      logFlag: "",
      username: "",
      userid: "",
      questionsList: [],
      questionsList1: [],
      ivalue: "",
      textarea: "",
    };
  },
  watch: {
    logFlag(val) {
      let res = getUserInfo();
      console.log(res)
      if (res) {
        this.username = JSON.parse(res).name;
        this.userid = JSON.parse(res)._id;
      } else {
        this.username = null;
        this.userid = null;
      }
    },
    ivalue(val) {
      this.questionsList = this.questionsList.filter(
        (v) =>
          !val ||
          this.$options.filters["filterSpace"](v.space)
            .toLowerCase()
            .includes(val.toLowerCase())
      );
      if (!val) {
        this.getData();
      }
    },
  },
  created() {
    this.getData();
  },
  methods: {
    answerSubmit(data) {
      let res1 = getUserInfo();

      let res = JSON.parse(res1);
      let submitData = {
        qid: data,
        content: this.textarea,
        uid: res._id,
        uname: res.name,
      };
      add(submitData).then((res) => {
        this.getData();
        this.textarea = "";
      });
    },
    handleSelect(data) {
      console.log("data: ", data);
      // this.getData();

      this.questionsList = this.questionsList1.filter((v) => v.space == data);
    },
    clickHot() {
      function sortId(a, b) {
        return JSON.parse(b.up).length - JSON.parse(a.up).length;
      }

      this.questionsList = this.questionsList.sort(sortId);
    },
    clickHome() {
      this.getData();
    },
    logoBtn() {
      console.log(111);
      this.getData();
    },
    Upvote(id) {
      if (this.userid) {
        userUp({ _id: id, userid: this.userid }).then((res) => {
          this.getData();
        });
      } else {
        this.$message({
          message: "please login first",
          type: "warning",
        });
      }
    },
    cancelUp(id, upList) {
      if (this.userid) {
        let list = JSON.parse(upList);

        let cancelList = list.filter((v) => v !== this.userid);

        userCancel({ _id: id, cancelList: JSON.stringify(cancelList) }).then((res) => {
          this.getData();
        });
      } else {
        this.$message({
          message: "please login first",
          type: "warning",
        });
      }

      //
      //
    },
    getData() {
      getAll().then((res) => {
        console.log(res)
        this.questionsList = res.data.data.map((v) => {
          let obj = { ...v };
          obj.createTime = rTime(obj.createTime) || obj.createTime;
          obj.upNum = JSON.parse(obj.up).length;
          let flag = JSON.parse(obj.up).find((v) => v == this.userid);
          if (flag) {
            obj.upFlag = true;
          } else {
            obj.upFlag = false;
          }
          obj.answerFlag = false;
          return obj;
        });
        this.questionsList1 = this.questionsList;
      });
    },
    answerList(data, key) {
      this.questionsList[key].answerFlag = !this.questionsList[key].answerFlag;
    },
  },
};
</script>

<style scoped>
.el-header {
  padding: 0;
}
.el-menu {
  border: none;
  background-color: #f5f7f8;
}
.footer {
  display: flex;
  margin-top: 30px;

  /* justify-content: space-between; */
}
.hand {
  cursor: pointer;
}
</style>
